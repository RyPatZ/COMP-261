public interface ExprNode {
    public int compute(Robot robot);//for compute
}
