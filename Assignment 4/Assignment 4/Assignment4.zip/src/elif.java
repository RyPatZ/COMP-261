import java.util.List;

public class elif  {
    List<ConditionNode> elfconditions ;//condition list
    List<RobotProgramNode> elfb ;//block list
    public elif (List<ConditionNode> elfconditions , List<RobotProgramNode> elfb ){
        this.elfconditions = elfconditions;
        this.elfb= elfb;
    }

}
