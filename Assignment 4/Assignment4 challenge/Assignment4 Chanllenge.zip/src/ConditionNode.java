public interface ConditionNode {// declare a condition interface
    public boolean compute(Robot robot);
}