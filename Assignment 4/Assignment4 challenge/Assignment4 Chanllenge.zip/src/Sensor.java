
//"fuelLeft" | "oppLR" | "oppFB" | "numBarrels" |
// "barrelLR" | "barrelFB" | "wallDist"
public interface Sensor extends ExprNode {}